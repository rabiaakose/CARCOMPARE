CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ad',
  `surname` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Soyad',
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL COMMENT 'E-Posta Adresi',
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Şifre',
  `created_at` datetime DEFAULT NULL COMMENT 'Oluşturulma Tarihi',
  `updated_at` datetime DEFAULT NULL COMMENT 'Güncellenme Tarihi',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='User Tablosu';